import 'package:get/get.dart';

class ControllerTaxConfiguration extends GetxController{

}